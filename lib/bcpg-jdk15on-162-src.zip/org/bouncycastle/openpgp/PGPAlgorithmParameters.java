package org.bouncycastle.openpgp;

public interface PGPAlgorithmParameters
{
}
